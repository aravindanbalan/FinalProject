/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
#ifndef CLUSTERMEMBER_HELPER_H
#define CLUSTERMEMBER_HELPER_H

#include "ns3/clustermember.h"

namespace ns3 {

/* ... */

}

#endif /* CLUSTERMEMBER_HELPER_H */

