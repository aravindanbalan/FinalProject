/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
#ifndef CLUSTERMANAGER_HELPER_H
#define CLUSTERMANAGER_HELPER_H

#include "ns3/clustermanager.h"

namespace ns3 {

/* ... */

}

#endif /* CLUSTERMANAGER_HELPER_H */

