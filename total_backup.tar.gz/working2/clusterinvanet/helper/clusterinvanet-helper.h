/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
#ifndef CLUSTERINVANET_HELPER_H
#define CLUSTERINVANET_HELPER_H

#include "ns3/clusterinvanet.h"

namespace ns3 {

/* ... */

}

#endif /* CLUSTERINVANET_HELPER_H */

