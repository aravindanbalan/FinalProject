/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */

#include "clustermanager.h"
#include <stdlib.h>
#include "ns3/icmpv4.h"
#include "ns3/assert.h"
#include "ns3/log.h"
#include "ns3/ipv4-address.h"
#include "ns3/socket.h"
#include "ns3/uinteger.h"
#include "ns3/boolean.h"
#include "ns3/inet-socket-address.h"
#include "ns3/packet.h"
#include "ns3/trace-source-accessor.h"
#include "MyTag.h"
namespace ns3 {

	using namespace std;
	NS_LOG_COMPONENT_DEFINE ("ClusterManager");

	NS_OBJECT_ENSURE_REGISTERED (ClusterManager);


	bool ClusterManager::instanceFlag = false;
	int ClusterManager::numClusters = 0;
	TypeId ClusterManager::tid;
	
	ClusterManager* ClusterManager::clusterMgr = NULL;

	ClusterManager* ClusterManager::getInstance()
	{
		if(!instanceFlag)
			{		
			clusterMgr = new ClusterManager();
			instanceFlag = true;
			numClusters = 0;
			tid = TypeId::LookupByName ("ns3::UdpSocketFactory");
			
		}
			return clusterMgr;
		
	}	

void ClusterManager::sampleTest(){
	
	cout<<"++++++++++++++++++++++++++++++++++++++++++++++++ sample test..."<<endl;
	
}
ClusterManager::ClusterManager ()
	{
		NS_LOG_FUNCTION (this);
		m_socket = 0;
		sendEvent = EventId ();
		sending = false;
		broadcast = false;
		dataSize = 256;
		m_sent = 0;
		m_received = 0;
		instanceFlag = false;
		numClusters = 0;
		done = false;
		numofMastersrecv = 0;
	}

	ClusterManager::~ClusterManager ()
	{
		NS_LOG_FUNCTION (this);
		instanceFlag = false;
		numClusters = 0;
	}

	bool ClusterManager::isDone(){
		return done;
	}

	void ClusterManager::setDone(bool value){
		
		done = value;
	}
		
		
	void ClusterManager::StartApplication (void)
	{
		NS_LOG_FUNCTION (this);
		
		cout<<"inside clustermanager start app"<<Simulator::Now()<<endl;
		
		if (m_socket == 0)
		{
			TypeId tid = TypeId::LookupByName ("ns3::UdpSocketFactory");
			m_socket = Socket::CreateSocket (GetNode (), tid);
		
		
			if(broadcast)
				m_socket->SetAllowBroadcast (true);
			
			if (sending)
				{
					if (Ipv4Address::IsMatchingType(peerAddress) == true)
					{
						m_socket->Bind();
						m_socket->Connect (InetSocketAddress (Ipv4Address::ConvertFrom(peerAddress), peerPort));
					}
					else if (Ipv6Address::IsMatchingType(peerAddress) == true)
					{
						m_socket->Bind6();
						m_socket->Connect (Inet6SocketAddress (Ipv6Address::ConvertFrom(peerAddress), peerPort));
					}
				}
				else
				{
					InetSocketAddress local = InetSocketAddress (Ipv4Address::GetAny (), peerPort);
					m_socket->Bind (local);
				}
		
		}
		m_socket->SetRecvCallback (MakeCallback (&ClusterManager::HandleRead, this));
		
		if (sending)
			ScheduleTransmit (Seconds (0.6));
	}

	void ClusterManager::StopApplication (void)
	{
		NS_LOG_FUNCTION (this);

		cout<<"inside clustermanager stop app"<<Simulator::Now()<<endl;
		if (m_socket != 0)
		{
			m_socket->Close ();
			m_socket->SetRecvCallback (MakeNullCallback<void, Ptr<Socket> > ());
			m_socket = 0;
		}

		Simulator::Cancel (sendEvent);

	}

	void ClusterManager::Setup (Ipv4Address address, uint16_t port, DataRate dr, bool toSend, bool broadcastaddr, int packetType)
	{
		peerAddress = address;
		peerPort = port;
		dataRate = dr;
		sending = toSend;
		broadcast = broadcastaddr;
		packet_Type = packetType;
	}

	void ClusterManager::HandleRead (Ptr<Socket> socket)
	{
		
		std::cout << "Yes------------------- ClusterManager" << std::endl;
		/*
		NS_LOG_FUNCTION (this << socket);
		Ptr<Packet> packet;
		Address from;

		

		while (packet = socket->RecvFrom (from))
		{
			if (InetSocketAddress::IsMatchingType (from))
		{
				NS_LOG_INFO ("At time " << Simulator::Now ().GetSeconds () << "s peer received " << packet->GetSize () << " bytes from " <<
						   InetSocketAddress::ConvertFrom (from).GetIpv4 () << " port " <<
						   InetSocketAddress::ConvertFrom (from).GetPort ());
		}
			
			packet->RemoveAllPacketTags ();
		packet->RemoveAllByteTags ();

		NS_LOG_LOGIC ("Echoing packet");
		socket->SendTo (packet, 0, from);      
			if (InetSocketAddress::IsMatchingType (from))
		{
			NS_LOG_INFO ("At time " << Simulator::Now ().GetSeconds () << "s server sent " << packet->GetSize () << " bytes to " <<
						   InetSocketAddress::ConvertFrom (from).GetIpv4 () << " port " <<
						   InetSocketAddress::ConvertFrom (from).GetPort ());
		}
		}
		* 
		* */
	}

	void ClusterManager::ScheduleTransmit (Time dt)
	{
		NS_LOG_FUNCTION (this << dt);
		sendEvent = Simulator::Schedule (dt, &ClusterManager::Send, this);
	}

	void ClusterManager::Send (void)
	{
		NS_LOG_FUNCTION (this);
	
		std::cout<<"Inside clustermanager send function"<<std::endl;
		MyTag sendTag;
		sendTag.SetPacketType(packet_Type);
    
		Ptr<Packet> p;
		p = Create<Packet> (dataSize);
		p->AddPacketTag(sendTag);

		// May want to add a trace sink
		m_socket->Send (p);

		NS_LOG_INFO ("At time " << Simulator::Now ().GetSeconds () << "s peer sent " << dataSize << " bytes to " <<
					   Ipv4Address::ConvertFrom (peerAddress) << " port " << peerPort);

	}

	int ClusterManager::getNumberOfClusters(){
		return numClusters;
	}

	int ClusterManager::getClusterIDFromTopic(int topic){
		
		map<int,int>::iterator p;
		p = topicClusterIDAssociationMap.find(topic);
		return p->second;
	}

	int ClusterManager::getClusterIDFromNode(Ptr<Node> node){

		map<Ptr<Node>,int>::iterator p;
		p = nodeClusterIDAssociationMap.find(node);
		if(p != nodeClusterIDAssociationMap.end())
		{
			return p->second;
		}
		else 
		{
			//cout<<"no cluster id for node\n";
			return -999;
		}	
		
	}

	void ClusterManager::putClusterIDForTopic(int topic, int clusterID){
		
		map<int,int>::iterator p;
		p = topicClusterIDAssociationMap.find(topic);
		if(p != topicClusterIDAssociationMap.end())
			topicClusterIDAssociationMap[topic] = clusterID;
		else
		topicClusterIDAssociationMap.insert(pair<int,int>(topic,clusterID));
	}

	void ClusterManager::putClusterIDForNode(Ptr<Node> node, int clusterID){
		
		map<Ptr<Node>,int>::iterator p;
		p = nodeClusterIDAssociationMap.find(node);
		if(p != nodeClusterIDAssociationMap.end())
			nodeClusterIDAssociationMap[node] = clusterID;
		else
		nodeClusterIDAssociationMap.insert(pair<Ptr<Node>,int>(node,clusterID));
	}	

	Cluster* ClusterManager::getClusterFromClusterID(int clusterID){
		
		//std::cout<<"*******************"<<endl;
		map<int, Cluster* >::iterator p;

		p = clusterMap.find(clusterID);
		//std::cout<<"11*******************"<<endl;
		if(p != clusterMap.end())
		{
			//std::cout<<"is there*******************"<<endl;
			return p->second;
		}
		else 
		{
			//std::cout<<"null*******************"<<endl;
			return NULL;
		}	
		
	}

	void ClusterManager::putClusterForClusterID(int clusterID, Cluster* cluster){
		
		map<int, Cluster* >::iterator p;
		p = clusterMap.find(clusterID);
		if(p != clusterMap.end())
			clusterMap[clusterID] = cluster;
		else
			clusterMap.insert(pair<int,Cluster* >(clusterID,cluster));
	}

	Cluster* ClusterManager::createNewCluster(int clusterID, int topic){
		
		Cluster* newCluster = new Cluster(clusterID, topic);
		return newCluster;
	}

	void ClusterManager::join_Cluster(Ptr<Node> node, int nodeID, int topic){
		
		map<int, int>::iterator p;
		p = topicClusterIDAssociationMap.find(topic);
		if(p != topicClusterIDAssociationMap.end())
		{
			int clusterID = topicClusterIDAssociationMap[topic];
			
			//get the cluster from ClsuterMap and add the node to the cluster
			Cluster* cluster = getClusterFromClusterID(clusterID);
			cluster->addNodeToCluster(node);
			
			setNodeIDForNode(node,nodeID);
			putClusterIDForNode(node,clusterID);
			putClusterForClusterID(clusterID,cluster);
			putClusterIDForTopic(topic,clusterID);
		}
		else{
			
			int clusterID = numClusters;
			Cluster* cluster = createNewCluster(clusterID, topic);
			//increment the number of clusters in the system as we created a new cluster
			numClusters++;
			cluster->addNodeToCluster(node);
			
			// add in three places
			//1. topic<--> clusterID map
			// 2. clusterMap
			// 3. node<--> clusterID map
			
			putClusterIDForTopic(topic,clusterID);
			putClusterForClusterID(clusterID,cluster);
			putClusterIDForNode(node,clusterID);
			setNodeIDForNode(node,nodeID);
			
		}

	}

	void ClusterManager::leave_Cluster(Ptr<Node> node, int nodeID){
		
		int clusterID = getClusterIDFromNode(node);
		if(clusterID != -999)
		{
			Cluster *cluster = getClusterFromClusterID(clusterID);
			cluster->removeNodeFromCluster(node);
			int clustersize = cluster->getNumNodes();
			if(clustersize == 0)
			{
				//remove all cluster references
				removeClusterIDForNode(node);
				int topic = cluster->getTopic();
				removeClusterIDForTopic(topic);
				removeClusterIDFromClusterMap(clusterID);		
			}
			
		}
	}

	bool ClusterManager::isMaster(Ptr<Node> node){
		
		int clusterID = getClusterIDFromNode(node);
		Cluster* cluster = getClusterFromClusterID(clusterID);
		return cluster->isMaster(node);
	}


	NodeContainer ClusterManager::getNodeContainer(){
		
		return clusterMgrNodeContainer;
	}

	void ClusterManager::setNodeContainer(NodeContainer nodeC){
		
		clusterMgrNodeContainer = nodeC;
		setClusterMgrNode(nodeC.Get (0));
	}

	Ptr<Node> ClusterManager::getClusterMgrNode(){
		
		return clusterMgrNode;
	}

	void ClusterManager::setClusterMgrNode(Ptr<Node> node){
		
		clusterMgrNode = node;
		//setClusterMgrSocket(node);
	}
	/*
	Ptr<Socket> ClusterManager::getClusterMgrSocket(){
		
		return clusterMgrSocket;
	}
	void ClusterManager::setClusterMgrSocket(Ptr<Node> node){
		
		 clusterMgrSocket = Socket::CreateSocket (node, tid);
	}
	*/
	int ClusterManager::getNodeIDForNode(Ptr<Node> node){
		
		map<Ptr<Node>, int >::iterator p;
		p = nodeNodeIDAssociationMap.find(node);
		return p->second;
	}
	void ClusterManager::setNodeIDForNode(Ptr<Node> node, int nodeID){
		
		map<Ptr<Node>, int >::iterator p;
		p = nodeNodeIDAssociationMap.find(node);
		if(p != nodeNodeIDAssociationMap.end())
			nodeNodeIDAssociationMap[node] = nodeID;
		else
			nodeNodeIDAssociationMap.insert(pair<Ptr<Node>,int>(node,nodeID));
	}

	void ClusterManager::eraseAllMaps(){
		
		 map<int, Cluster*>::iterator p;
		 clusterMap.erase ( p, clusterMap.end() );
		 
		 map<Ptr<Node>, int >::iterator p1;
		 nodeClusterIDAssociationMap.erase ( p1, nodeClusterIDAssociationMap.end() );
		 
		 map<int, int >::iterator p2;
		 topicClusterIDAssociationMap.erase ( p2, topicClusterIDAssociationMap.end() );
		 
	}

	void ClusterManager::removeClusterIDForNode(Ptr<Node> node){
		
		nodeClusterIDAssociationMap.erase(node);
	}
	void ClusterManager::removeClusterIDForTopic(int topic){
		
		topicClusterIDAssociationMap.erase(topic); 
	}
	void ClusterManager::removeClusterIDFromClusterMap(int clusterID){
		
		clusterMap.erase(clusterID); 
		numClusters--;
	}

	int ClusterManager::getMasterNodeIDFromCluster(int clusterID){
		
		Cluster* cluster = getClusterFromClusterID(clusterID);
		return getNodeIDForNode(cluster->getMaster());
	}

	vector<Ptr<Node> > ClusterManager::getSlaveNodesFromCluster(int clusterID){
		
		Cluster* cluster = getClusterFromClusterID(clusterID);
		return cluster->getSlaveNodes();
	}
	
	string ClusterManager::getSlaveNodeIDsFromCluster(int clusterID){
		
		vector<Ptr<Node> > slaves = getSlaveNodesFromCluster(clusterID);
		//vector<int> slaveIDs;
		
		string slaveString;
		
		for( vector<Ptr<Node> >::iterator iter = slaves.begin(); iter != slaves.end(); ++iter )
		{
			Ptr<Node> node = *iter;
			//slaveIDs.push_back(getNodeIDForNode(node));
			int nodeID = getNodeIDForNode(node);
			std::ostringstream s;
			s<<nodeID;
			std::string ss(s.str());
			slaveString.append(ss);
			slaveString.append(1,',');
			
		}
		slaveString = slaveString.substr(0, slaveString.size()-1);
		
		return slaveString;
	}
	
	int randomNumberGenerator(int numNodes)
	{
			int v1 = rand() % numNodes; 
			return v1;
	}

	void ClusterManager::choose_Master(int clusterID){
		
		// as of now choosing the first node as master in each cluster
		//std::cout<<"1111"<<std::endl;
		Cluster* cluster = getClusterFromClusterID(clusterID);
		//std::cout<<"222"<<std::endl;
		std::vector < Ptr<Node> > clusterNodes = cluster->getNodeList();
		
		//std::cout<<"1333"<<std::endl;
		
		// setting the first node in the list to be the master
		// replace this with the algorithm needed below
		
		//cluster->setMaster(clusterNodes.front());
		
		
		/////// New Algorithm /////////////////////
		unsigned int numNodes = clusterNodes.size();
		int random_master_index;
		Ptr<Node> masterNode;
		
		while(1)
		{
			random_master_index = randomNumberGenerator(numNodes); 
			//std::cout<<"random : "<<random_master_index<<std::endl;
			masterNode = clusterNodes.at(random_master_index);
			
			vector<int>::iterator got;
			
			got = find (chosenMastersSet.begin(), chosenMastersSet.end(), random_master_index);
			if(got == chosenMastersSet.end()){ // element not found, then insert it
				chosenMastersSet.push_back(random_master_index);
				break;
			}
		}
		
		cluster->setMaster(masterNode);
		if(chosenMastersSet.size() == numNodes)
			chosenMastersSet.erase (chosenMastersSet.begin(),chosenMastersSet.end());
		
		//////////////////////////////////////
		
		putClusterForClusterID(clusterID, cluster);
		
	}
	int ClusterManager::getTopicFromNode(Ptr<Node> node){
		
		int clusterID = getClusterIDFromNode(node);
		Cluster* cluster = getClusterFromClusterID(clusterID);
		return cluster->getTopic();
		
	}
	
	int ClusterManager::getMasterNodeIDFromSlaveID(Ptr<Node> slaveNode){
		
		int clusterID = getClusterIDFromNode(slaveNode);
		return getMasterNodeIDFromCluster(clusterID);
	}

}

