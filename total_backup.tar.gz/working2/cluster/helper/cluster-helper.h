/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
#ifndef CLUSTER_HELPER_H
#define CLUSTER_HELPER_H

#include "ns3/cluster.h"

namespace ns3 {

/* ... */

}

#endif /* CLUSTER_HELPER_H */

